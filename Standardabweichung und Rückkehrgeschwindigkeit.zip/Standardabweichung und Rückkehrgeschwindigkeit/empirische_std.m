%% Empirische Standardabweichung 
clc
clear

format long 
dates_20years = readtable("data_OBS_DEU_P1D_T2M_20years");
temp = table2cell(dates_20years);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end
% Im nächsten Teil wird eine Temperaturmatrix 20x365 aufgestellt, wobei (i,j)
% der Eintrag des i-ten Jahres im j-ten Tag ist. 
temp = str2double(temp);
temp_matrix = zeros(20,365);
s = 1;
t = 365;

for i = 1:20
    temp_matrix(i,:) = temp(s:t);
    s = t+1;
    t = 365*(i+1); 
end

% Berechnung und plotten der empirischen Standardabweichung in Ulm 
std(temp_matrix)
plot(std(temp_matrix))
title('empirische Standardabweichung in Ulm','FontSize',14);
ylabel('Standardabweichung','FontSize',14);
xlabel('Monate','FontSize',14);
legend('Standardabweichung','FontSize',13);
xticks(linspace(1,365,12))
k = {'J', 'F' , 'M' ,'A' ,'M' , 'J' , 'J' ,'A', 'S', 'O', 'N' ,'D' , ''};
xticklabels(k);
    


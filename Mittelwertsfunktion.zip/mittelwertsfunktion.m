%% Berechnung der Mittelwertsfunktion m
clear all
clc
rng('default');
format long 
dates_30years = readtable("data_OBS_DEU_P1D_T2M_5155_30years");
temp = table2cell(dates_30years);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

days = (1:length(temp))';

% Berechnung der Koeffizienten für die Funktion, die den Mittelwert
% darstellt, zu dem die Temperatur zurückzukehren tendiert.

m= @(b,t) b(1) + b(2)*t + b(3)*sin(2*pi*t/365+b(4));

N = length(temp);
omega  = 2*pi/365;
y = str2double(temp);
t = (1:N)';

  A  = [ones(N,1) ,t , sin(omega*t),cos(omega*t)];
  coeff_sin = A\y;
  
  beta_1 = coeff_sin(1);
  beta_2 = coeff_sin(2);
  beta_3 = coeff_sin(3);
  beta_4 = coeff_sin(4);
  
  phi = atan(beta_4/beta_3);
  c = beta_3/cos(phi);
  
  new_coeff_sin = [beta_1,beta_2,c,phi]




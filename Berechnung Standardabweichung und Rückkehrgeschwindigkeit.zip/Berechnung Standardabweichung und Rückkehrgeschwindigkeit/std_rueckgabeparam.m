%% Berechnung der konstanten Monatlichen Varianzen + Parameter für die
%% Rückkehrgeschwindigkeit
clc
clear
format long 
dates_20years = readtable("data_OBS_DEU_P1D_T2M_20years");
temp = table2cell(dates_20years);
temp = string(temp);
years = 20;

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp = str2double(temp);

%% 1. Variante zu Berechnung der Standardabweichung 

% Aufstellen des Cell-Arrays mit 12 Zellen. Die i-te Zelle enthält die Durchschnittstemperatur 
% des i-ten Monats (i = 1,...,12). Die Durchschnittstemperatur der Schaltjahre wurde
% weggelassen. 

temp_cell_var1 = cell(1,12); 

N = [31 28 31 30 31 30 31 31 30 31 30 31]; % N enthält die Anzahl der Tage für jeden Monat von Januar bis Dezember.
 
% "month" läuft von 1-12 (Januar-Dezember). Je nach dem in welchem
% Schleifendurchlauf man sich befindet, ist "begin" anders definiert. Für den Monat Februar gilt begin = 32, 
% da am 32. Tag im Jahr der erste Tag im Februar ist. Die Variable begin
% wird mit jedem Schleifendurchlauf um 365 erhöht, so wird der Vektor nach und nach für jeden einzelnen Monat
% mit werten gefüllt.

 for  month = 1:12
     
    N_mue = N(month);
     switch month
         case 1 
             begin = 1;
         case 2 
             begin = 32;
         case 3 
             begin = 60;         
         case 4 
             begin = 91;         
         case 5
             begin = 121;
         case 6 
             begin = 152;
         case 7 
             begin = 182;
         case 8 
             begin = 213;
         case 9 
             begin = 244;
         case 10 
             begin = 274;
         case 11  
             begin = 305;
         case 12 
             begin = 335;      
     end     
      s = 1;
      u = s+N_mue-1;
      
            for t = begin:365:length(temp)
                    k = t;  
                    temp_cell_var1{month}(s:u) = temp(k:k+(N_mue-1));
                    s = u+1;
                    u = u+N_mue;    
            end
            
% Berechung der Varianz, die auf die die quadratische Variation basiert.
summe_var1= 0;
 for i = 1:N_mue*years-1
    summe_var1 = summe_var1 +  (temp_cell_var1{month}(i+1) - ...
                 temp_cell_var1{month}(i))^2;
 end  
   sigma_var1(month) = summe_var1/(N_mue*years);
   
 end       
 
%% Berechnung des Parameters  alpha für die Rückkehrgeschwindigkeit
% Im nächsten Teil wird der Parameter für die Rückkehrgeschwindigkeit
% berechnet.
% Dann wird der Vektor für die Varianzen initialisiert.
% Die Standardabweichung ändert sich monatlich, weshalb die Tage im 
% gleichen Monat mit demselben Wert initialisiert werden.
% Beispiel für Januar sigma_all(1:31) = 6.2 

sigma_all = zeros(7300,1);  
for month = 1:12 
 
      N_mue = N(month);
  
    switch month
         case 1 
             begin = 1;
         case 2 
             begin = 32;
         case 3 
             begin = 60;         
         case 4 
             begin = 91;         
         case 5
             begin = 121;
         case 6 
             begin = 152;
         case 7 
             begin = 182;
         case 8 
             begin = 213;
         case 9 
             begin = 244;
         case 10 
             begin = 274;
         case 11  
             begin = 305;
         case 12 
             begin = 335;

    end    
        for t = begin:365:length(temp)
            
                u = t+N_mue-1;
               sigma_all(t:u) = sigma_var1(month);
        end
      
end

   m = @(t) 8.635 + 2.810*10^-5*t - 9.5654*sin(2*pi/365*t+1.2605);
   Y = @(t) (m(t) - temp(t))/sigma_all(t);
   summe_1 = 0;
   summe_2 = 0;
   
   for i = 2:length(temp)
       
       summe_1 = summe_1 + Y(i-1)*(temp(i) - m(i));
       summe_2 = summe_2 + Y(i-1)*(temp(i-1) - m(i-1));
       
    end 
   
   alpha = -log(summe_1/summe_2);
   
%% 2. Variante zur Berechnung der Standardabweichung

% Aufstellen des Cell-Arrays mit 12 Zellen. Die i-te Zelle enthält die Durchschnittstemperatur 
% des i-ten Monats (i = 1,...,12). Die Durchschnittstemperatur der Schaltjahre wurde
% weggelassen. 

temp_cell_var2 = cell(1,12);
 for  month = 1:12

    N_mue = N(month);

     switch month
         case 1 
             begin = 1;
         case 2 
             begin = 32;
         case 3 
             begin = 60;         
         case 4 
             begin = 91;         
         case 5
             begin = 121;
         case 6 
             begin = 152;
         case 7 
             begin = 182;
         case 8 
             begin = 213;
         case 9 
             begin = 244;
         case 10 
             begin = 274;
         case 11  
             begin = 305;
         case 12 
             begin = 335;

     end    
     
  s = 1;
  u = s+N_mue-1;
  
        for t = begin:365:length(temp)
            
                k = t;  
                temp_cell_var2{month}(s:u) = temp(k:k+(N_mue-1));
                s = u+1;
                u = u+N_mue;    
        end
       
% Berechnung der Varianz die auf die Regression der SDE basiert.  
summe_var2 = 0;
 
 for i = 1:N_mue*years-1
     
 summe_var2 = summe_var2 +  (temp_cell_var2{month}(i+1)- (m(i) - m(i-1))-...
              alpha*m(i-1)-(1-alpha)*temp_cell_var2{month}(i))^2;
 end 
 sigma_var2(month) = 1/(N_mue*years-2)*summe_var2;
 
 end 
 
 % Berechnung der Standardabweichungen für Ulm mit beiden Methoden 
 sigma_var1 = sqrt(sigma_var1);
 sigma_var2 = sqrt(sigma_var2);
 
 st = [sigma_var1' , sigma_var2']
 alpha 
 

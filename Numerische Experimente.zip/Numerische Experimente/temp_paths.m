function [paths] = temp_paths(T0,A,B,C,alpha,omega,phi,...
                   sigma,lambda,N_paths)

mj = @(t) A + B*t + C*sin(omega*t + phi);
T = [T0,zeros(1,N_paths)];

    for j = 1:length(T)
    
        T(j+1) = mj(j+1) + (1-alpha)*(T(j) - mj(j)) + ...
            (randn-lambda)*sigma; 
        
   end
    paths = T;
end

function [call_price] = monte_carlo(T0,...
    A,B,C,alpha,omega,phi,sigma,N_sim,N_days,lambda,K,r)

  
    payoff_call = zeros(1,N_sim);
    omega_H = zeros(1,N_sim);
    
    for t = 1:N_sim
        t
        path = temp_paths(T0,A,B,C,alpha,omega,phi,sigma,...
               lambda,N_days);
        hdd_i = max(18 - path,0);
        omega_H(t) = sum(hdd_i);
        payout = max(omega_H(t)-K,0);
        payoff_call(t) = exp(-r*N_days)*payout;
        
        
    end
    
    
    call_price = sum(payoff_call)/N_sim;
    
   
    
    
    
    

    
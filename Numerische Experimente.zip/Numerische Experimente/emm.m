function [call_price] = emm(To,...
    A,B,C,alpha,omega,phi,sigma,tn,lambda,K,r)
rng('default');
mto = A + C*sin(phi);
sum_mue = 0;
sum_var = 0;
sum_cov = 0;
doppel_sum_cov= 0;
mt = @(t) A+B*t+C*sin(omega*t + phi);
for ti = 1:tn
    
    Epti = (To - mto)*exp(-alpha*ti)+mt(ti);
    EQti = Epti -((lambda*sigma)/alpha*(1-exp(-alpha*ti)));
    VarTti = (sigma^2)/(2*alpha)*(1-exp(-2*alpha*ti));
    
    for tj = ti+1:tn
        CovTtiTtj = exp(-alpha*(tj-ti))*VarTti;
        sum_cov = sum_cov + CovTtiTtj;
    end 
    
    sum_mue  = sum_mue+ EQti;
    sum_var  = sum_var + VarTti;
    doppel_sum_cov  = doppel_sum_cov + sum_cov;
    
end 
mue_Q= 18*tn - sum_mue;
var_Q = sum_var+2*doppel_sum_cov;
an = (K-mue_Q)/(sqrt(var_Q));
call_price = exp(-r*tn)*(sqrt(var_Q/(2*pi))*exp(-(an^2)/2)...
    +(mue_Q-K)*normcdf(-an));
             
 
    
    
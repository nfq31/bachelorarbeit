%% Numerische Experimente mit verschiedenen Parameter 
% Die gesamten Berechnungen beziehen sich auf eine HDD Call-Option.
clear all
close all
%Definition der Parmater für SDE (Die Parameter
%A,B,C,omega,phi,alpha,lambda,r bleiben im Laufe der Experimente gleich)
rng(17) % Um Ergebnisse reproduzierbar zu machen
A = 8.635;
B = 2.810*10^-5;
C = -9.565;
omega = 2*pi/365;
phi = 1.261;
alpha = 0.202; 
T=31; % Laufzeit in Tagen (Januar)
N_sim = 100000; % Anzahl der Monte-Carlo-Simulationen
sigma = 2.95; % Standardabweichung für Januar
lambda = 0.08; % Marktpreis des Risikos
r = 0.05; %risikoloser Zinssatz


%% 1. Experiment - 5 verschiedene Strike Preise
 % Im ersten Experiment werden verschiedene Preise mit 5 unterschiedlichen 
 % Strike Preisen berechnet 
T0 = 0;   % Anfangstemperatur

K_all = [400 405 410 415 420];

i=0;
call_preis_mc_K = zeros(1,length(K_all));
call_preis_emm_K = zeros(1,length(K_all));

% Berechnung der Preise mit Monte-Carlo-Simulationen und risikoneutraler
% Bewertung
for K = K_all 
    i= i+1;
    [call_preis_mc_K(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_K(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 




%% 2. Experiment - verschiedene Anfangswerte T0;
% Im 2. Experiment werden verschiedene Preise mit unterschiedlichen
% Anfangswerten T0 berechnet
call_preis_mc_T0 = zeros(1,5);
call_preis_emm_T0 = zeros(1,5);
K = 400; %Strike Preis
i=0;
T0_all = [-3 -2 -1 0 1 2 3 ]; % Anfangstemperaturen

% Berechnung der Preis mit Monte-Carlo-Simulationen und risikoneutraler
% Bewertung
for T0 = T0_all 
    i= i+1;
    [call_preis_mc_T0(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_T0(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 



%% 3. Experiment - verschiedene Laufzeiten T
% Im 3. Experiment werden verschiedene Preise mit unterschiedlichen
% Laufzeiten berechnet 
i = 0;
T0 = 0; % Anfangstemperatur 
K = 400; % Strike Preis
T_all = [30 35 40 50 60 90]; % Laufzeiten
call_preis_mc_Time = zeros(1,length(T_all));
call_preis_emm_Time = zeros(1,length(T_all));

% Berechnung der Preis mit Monte-Carlo-Simulationen und 
% risikoneutraler Bewertung  
for T = T_all 
    i= i+1;
    [call_preis_mc_Time(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_Time(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 


%% Plots
%In den nächsten Experimenten werden die Preise geplottet, mit
%verschiedenen Strike Preisen, Anfangstemperaturen und Marktpreisen des
%Risikos

%% 4. Experiment -  verschiedene Strike Preise 

K_all = 340:5:450; %Strike Preise
T0 = 0; % Anfangstemperatur
T = 31; % Laufzeit
i=0;
call_preis_mc_K_plot = zeros(1,length(K_all));
call_preis_emm_K_plot = zeros(1,length(K_all));

% Berechnung der Preise mit Monte-Carlo-Simulationen und risikoneutraler
% Bewertung
for K = K_all 
    i= i+1;
    [call_preis_mc_K_plot(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_K_plot(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 



figure(1);
plot(K_all,call_preis_mc_K_plot);
hold on 
plot(K_all,call_preis_emm_K_plot);
title('Verschiedene Strike Preise','FontSize',14);
legend('Monte-Carlo-Simulationen','Risikoneutrale Bewertung','FontSize',13)
xlabel('Strike Preise','FontSize',14);
ylabel('Preise','FontSize',14);


%% 5. Experiment - verschiedene Anfangswerte T0 ;

call_preis_mc_T0_plot = zeros(1,5);
call_preis_emm_T0_plot = zeros(1,5);
K = 400; % Strike Preis
T = 31;  % Laufzeit in Tagen
i=0;
T0_all = linspace(-5,5,100);

% Berechnung der Preise mit Monte-Carlo-Simulationen und risikoneutraler 
% Bewertung
for T0 = T0_all 
    i= i+1;
    [call_preis_mc_T0_plot(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_T0_plot(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 

figure(2)
plot(linspace(-5,5,100),call_preis_mc_T0_plot);
hold on 
plot(linspace(-5,5,100),call_preis_emm_T0_plot);
title('Verschiedene Anfangstemperaturen','FontSize',14);
xlabel('Anfangstemperaturen','FontSize',14);
ylabel('Preise','FontSize',14)
legend('Monte-Carlo-Simulationen','Risikoneutrale Bewertung','FontSize',13);


%% 6. Experiment - Marktpreis des Risikos lambda;

K = 400; % Strike Preis
T = 31;  % Laufzeit
i=0;
lambda_all = linspace(-1,1,100); %Marktpreis des Risikos zwischen -1 und 1 
T0=0; % Anfangstemperatur
% Berechnung der Preis mit Monte-Carlo-Simulationen und risikoneutraler
% Bewertung
for lambda  = lambda_all 
    i= i+1;
    [call_preis_mc_lambda_plot(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
     
    [call_preis_emm_lambda_plot(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);   
    
end 

figure(3)
xl={'Marktpreis des Risikos - $\lambda$'};
plot(lambda_all,call_preis_mc_lambda_plot);
hold on 
plot(lambda_all,call_preis_emm_lambda_plot);
title('Verschiedene Marktpreise des Risikos','FontSize',14);
xlabel(xl,'interpreter','latex','FontSize',15)
ylabel('Preise','FontSize',15);
legend('Monte-Carlo-Simulationen','Risikoneutrale Bewertung','FontSize',12,...
'Location','NorthWest');


 %% 7. Experiment - verschiedene Anfangstemperaturen 
 
call_preis_mc_T0_plot = zeros(1,5);
call_preis_emm_T0_plot = zeros(1,5);
K = 400; % Strike Preis
T = 31; % Laufzeit
i=0;
T0_all = linspace(-5,5,100); % Anfangstemperaturen von -5 bis 5 
for T0 = T0_all 
    i= i+1;
    [call_preis_mc_T0_plot(i)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                    sigma,N_sim,T,lambda,K,r);
    [call_preis_emm_T0_plot(i)] = emm(T0,...
    A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);              
end 


figure(4)
plot(linspace(-5,5,100),call_preis_mc_T0_plot);
hold on 
plot(linspace(-5,5,100),call_preis_emm_T0_plot);
title('Verschiedene Anfangstemperaturen','FontSize',14);
xlabel('Anfangstemperaturen','FontSize',14);
ylabel('Preise','FontSize',14)
legend('Monte-Carlo-Simulationen','Risikoneutrale Bewertung','FontSize',13);

 

%% 8. Experiment - Plot unterschiedlicher Laufzeiten
% Im letzten Experiment werden unterschiedliche Laufzeiten zu zwei
% unterschiedlichen Strike Preisen geplottet

T_all = 1:100; %Laufzeiten 
K_all = [300 400];%Strike Preise
i   = 0;
j   = 1;
T0  = 0; % Anfangstemperatur
% Berechnung der Preise mit Monte-Carlo-Simulationen und risikoneutraler
% Bewertung
for K = K_all
    i = 0;
    for T  = T_all
        i= i+1;
        [call_preis_mc_test_plot(i,j)] = monte_carlo(T0,A,B,C,alpha,omega,phi,...
                                        sigma,N_sim,T,lambda,K,r);   
        [call_preis_emm_test_plot(i,j)] = emm(T0,...
         A,B,C,alpha,omega,phi,sigma,T,lambda,K,r);
    end 
    
    subplot(1,2,j);
    hold on 
    j = j+1;
    
end

subplot(2,2,1);
line1 = plot(T_all,call_preis_mc_test_plot(:,1),'DisplayName','Monte-Carlo-Simulationen');
hold on 
line2 = plot(T_all,call_preis_emm_test_plot(:,1),'DisplayName','Risikoneutrale Bewertung');
title(' K = 300 HDD','FontSize',11);
xlabel('Laufzeiten','FontSize',12);
ylabel('Preise','FontSize',12)

subplot(2,2,2);
plot(T_all,call_preis_mc_test_plot(:,2));
hold on
plot(T_all,call_preis_emm_test_plot(:,2));
title('K = 400 HDD','FontSize',11);
xlabel('Laufzeiten','FontSize',12);
ylabel('Preise','FontSize',12);

ax  = subplot(2,2,3,'Visible','off');
axPos = ax.Position;
delete(ax);

hl = legend([line1,line2],'FontSize',11);
hl.Position(1:2) = axPos(3:4);
sgtitle('Verschiedene Laufzeiten + Ausübungspreise','Fontweight','bold','FontSize',11)



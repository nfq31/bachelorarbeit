%% Durchschnittstemperatur in Ulm für 2 Jahre 
format long 
dates_2years = readtable("data_OBS_DEU_P1D_T2M_5155_2years");
temp = table2cell(dates_2years);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp = str2double(temp);

% Plotten der Durchschnittstemperatur in Ulm für 2 Jahre 
plot(temp)
hold on 
title('Durchschnittstemperatur 2 Jahre Ulm','FontSize',14)
xlabel('Tage','FontSize',14);
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14);




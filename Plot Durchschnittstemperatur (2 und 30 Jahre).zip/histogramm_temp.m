%% Histogram der historischen täglichen Temperaturänderungen in Ulm 
%% für 10 Jahre 

clear all
clc

format long 
dates_10years = readtable("data_OBS_DEU_P1D_T2M_5155_10years");
temp = table2cell(dates_10years);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp = str2double(temp);
N = length(temp);
days = (1:N)';

% Berechnung der Temperaturveränderung jeden Tag
temp_changes = temp(2:N) - temp(1:N-1);
x = linspace(-10,10,length(temp_changes));

% Plotten des Hisograms und Interpolation mit histfit
histfit(temp_changes,80)
title('Histogramm Temperaturänderungen Ulm','FontSize',14)
legend('Veränderungen','Interpolation','FontSize',13,'Location','northwest')
xlabel('Temperaturänderungen','FontSize',14);
ylabel('Anzahl der Beobachtungen','FontSize',14)
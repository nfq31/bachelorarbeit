%% Durchschnittstemperatur in Ulm für 30 Jahre 
rng('default');
format long 
dates_30years = readtable("data_OBS_DEU_P1D_T2M_5155_30years");
temp = table2cell(dates_30years);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end
days = (1:length(temp))';
%Berechnung der Koeffizienten der Gerade und Sinuskurve. Die Funktion wird
%in eine lineare Funktion umgeschrieben. Anschließend wird mit der Methode
%der kleinsten Quadrate die Funktion berechnet.

modelfun_sin  = @(b,t) b(1) + b(2)*sin(2*pi*t/365+b(3));
modelfun_ger  = @(b,t) b(1) + b(2)*t;

N = length(temp);
omega  = 2*pi/365;
y = str2double(temp);
t = (1:N)';
beta_1 = sin(omega*t);
beta_2 = cos(omega*t);
 
 A  = [ones(N,1),beta_1,beta_2];
 B  = [ones(N,1),t];
 
  coeff_sin = A\y;
  coeff_ger = B\y;
  
  a = coeff_sin(1);

  alpha_1 = coeff_sin(2);
  alpha_2 = coeff_sin(3);
  
  phi = atan(alpha_2/alpha_1);
  c = alpha_1/cos(phi);
  new_coeff_sin = [a,c,phi];
  new_coeff_ger = coeff_ger;

% Plotten der Durchschnittstemperatur
f = figure(1);
f.Position = [100 100 1040 300];
plot(y)
xticks(linspace(1,10957,7))
k = 1992:5:2023;
xticklabels({k});

hold on 
plot(days,modelfun_ger(new_coeff_ger,days),'LineWidth',2);
legend('Durchschnittstemperatur','Ausgleichsgerade','FontSize',13,'Location','SouthWest')
title('Durchschnittstemperatur Ulm 30 Jahre','FontSize',14)
xlabel('Jahr','FontSize',14)
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14)


g = figure(2)
g.Position = [100 100 1040 300];
plot(y)
xticks([linspace(1,10957,7)])
k = 1992:5:2023;
xticklabels({k});

hold on 
plot(days,modelfun_sin(new_coeff_sin,days),'r','LineWidth',2);
legend('Durchschnittstemperatur','Saisonalität der Temperatur','FontSize',13,'Location','SouthWest');
title('Durchschnittstemperatur Ulm 30 Jahre','FontSize',14);
xlabel('Jahr','FontSize',14)
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14)

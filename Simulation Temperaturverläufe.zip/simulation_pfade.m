%% Algorythmus zur Simulation einiger Temperaturverläufe 
clear 
clc
randn('state',4);
% Initialisieren der Parameter 
N =  3500;
A = 8.635 ;
B = 2.81*10^(-5);
C= -9.565;
alpha   = 0.202;
omega   = 2*pi/365;
phi     = 1.261;
sigma   = 2.759;
normv   = randn(1,N-1);
Tj      = @(j) A + B*j + C*sin(omega*j + phi);
T       = zeros(N,1);

% Simulation einiger Temperaturverläufe
for j = 2:length(T)-1
   
        T(j) = (1-alpha)*(T(j-1) - Tj(j-1)) + Tj(j-1) + normv(j)*sigma;
        
end

subplot(2,1,1)
plot(T)
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',13);
xlabel('Tage','FontSize',14);
title('Simulation von Temperaturverläufen','FontSize',14);



%% Temperaturverläufe Ulm für 3500 Tage

dates = readtable("data_OBS_DEU_P1D_T2M_5155_30years");
temp = table2cell(dates);
temp = string(temp);
for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp = str2double(temp);
temp = temp(1:3500);
subplot(2,1,2)
plot(temp)
title('Temperatur in Ulm','FontSize',14);
xlabel('Tage','FontSize',14);
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14)


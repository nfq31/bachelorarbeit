function [paths] = temp_paths(T0,A,B,C,alpha,omega,phi,...
                   sigma,N)

mj = @(j) A + B*j + C*sin(omega*j + phi);
normv = randn(1,N-1);
T = [T0,zeros(1,N-1)];

    for j = 2:length(T)-1
    
        T(j) = (1-alpha)*(T(j-1) - mj(j-1)) + mj(j-1) + ...
            normv(j)*sigma;
        
   end
    paths = T;
end
%% Vergleich Simulation mit dem Jahr 2020
clc 
clear
dates = readtable("data_OBS_DEU_P1D_T2M_5155_year_2021");
temp = table2cell(dates);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp_2021 = str2double(temp)';

% Initialisierung der Parameter 
A = 8.635;
B = 2.810*10^(-5);
C = -9.565;
alpha = 0.202;
omega = (2*pi)/365;
phi = 1.261; 
sigma = 2.75;
T0 = -1;  %Anfangstemperatur 01.01.2021
N  = 365;

m = @(t) A + B.*t + C*sin(omega.*t+phi);
mt = m(linspace(1,365,365));
temp = temp_paths(T0,A,B,C,alpha,omega,phi,sigma,N); %Simulation einiger Pfade für
% das Jahr 2021 

f = figure(1);
set(f, 'Position', [100, 150, 1000, 350]);

subplot(1,2,1)
fkt_2 = plot(temp_2021','r','DisplayName','simulierte Daten');
hold on 
plot(temp,'k');
xlabel('Tage','FontSize',15);
ylabel('$\textup{Temperatur in}\ ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14);
subplot(1,2,2)
fkt = plot(linspace(1,365,365),mt,'b','DisplayName','Ausgleichsfunktion');
hold on 
fkt_1 = plot(temp_2021,'r','DisplayName','Rohdaten');
xlabel('Tage','FontSize',14);
ylabel('$\textup{Temperatur in}\  ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14);
hold off
sgtitle('Überprüfung Datensimulation 2021','FontSize',15,'fontweight','bold');

t = 1000;
for i = 1:t
   
    temp = temp_paths(T0,A,B,C,alpha,omega,phi,sigma,N+1);
    error(:,i) = temp(1:N)-temp_2021(1:N);
    
end 
for j = 1:N
    
    error_avg(j) = sum(error(j,:))/t;
end 



figure(2)
plot(error_avg,'r*');
title('Durchschnittlicher Fehler Simulation 2021','FontSize',14);
xlabel('Tage','FontSize',14);
ylabel('$\textup{Temperatur in} ^\circ \textup{C}$','interpreter',...
    'latex','FontSize',14);
xticks(linspace(1,365,12))
k = {'J', 'F' , 'M' ,'A' ,'M' , 'J' , 'J' ,'A', 'S', 'O', 'N' ,'D' , ''};
xticklabels(k);







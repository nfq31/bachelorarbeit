%% HDD Indizes in Ulm von 1992 - 2021
% Dieses Skript berechnet die HDD-Indizes für das Beispiel in Kapitel 2.

clc 
clear

dates = readtable("Januar_1992-2022");
temp = table2cell(dates);
temp = string(temp);

for k = 1:length(temp)
    string_temp = convertStringsToChars(temp(k));
    ind         = strfind(string_temp,'"');
    x1          = ind(5);
    x2          = ind(6);
    x_korr      = string_temp(x1+1:x2-1);
    temp(k)        = x_korr;
    
end

temp = str2double(temp);

%Aufstellen Januar-Matrix, Spalte (i,j) Temperatur an Tag i im Jahr j im Januar
s = 1;
t =31;
for i = 1:31
    
    temp_matrix(:,i) = temp(s:t);
    s = 31*i+1;
    t = 31*(i+1);
    
end 
hdd = zeros(1,10)';
for ind = 1:31
    
    hdd(ind) = sum(max(18-temp_matrix(:,ind),0)); 
    
end
x = 1:31;
figure(1)
plot(hdd,'b')
hold on 
title("HDD-Werte in Ulm 1992-2022",'FontSize',14);
xlabel("Jahr",'FontSize',14);
ylabel("HDD",'FontSize',14);


xticks(linspace(3,29,6))
xticklabels({'1995','2000','2005','2010','2015','2020'});

coeff = polyfit(x,hdd,1);
plot(x,polyval(coeff,x),'r')

legend("HDD-Werte","Ausgleichsgerade",'FontSize',13)

hdd





    
    